package sample.process.operator;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import sample.process.util.TXUtil;

import com.ibm.bpe.api.ProcessTemplateData;
import com.ibm.websphere.sca.ServiceManager;
import com.ibm.websphere.sca.ServiceRuntimeException;

/**
 * 
 * @author lizh@cn.ibm.com
 *
 */
public class ProcessOperatorImpl {

	private static volatile Context context = null;
	private static volatile DataSource dataSource = null;
	private static final String JDBC_JNDI_REF_NAME = "jdbc/TestDB";

	/**
	 * 
         CONNECT TO WPRCSDB;
		 CREATE SCHEMA HWTEST AUTHORIZATION DB2ADMIN; 
		 COMMENT ON Schema HWTEST IS 'the schema for HuaWei Test';
         CREATE TABLE HWTEST.TEST_T_FOR_HUAWEI ( ID VARCHAR (50)  NOT NULL , NAME VARCHAR (50)  NOT NULL  , CONSTRAINT CC1366694914487 PRIMARY KEY ( ID, NAME)  ) IN USERSPACE1 ;
         CONNECT RESET;
	 */
	private static String INSTER_SQL = "INSERT INTO HWTEST.TEST_T_FOR_HUAWEI (ID, NAME ) VALUES ('";
	private static String DELETE_SQL = "DELETE FROM HWTEST.TEST_T_FOR_HUAWEI WHERE ";
	
	/**
	 * Default constructor.
	 */
	public ProcessOperatorImpl() {
		super();
	}

	/**
	 * Return a reference to the component service instance for this implementation
	 * class.  This method should be used when passing this service to a partner reference
	 * or if you want to invoke this component service asynchronously.    
	 *
	 * @generated (com.ibm.wbit.java)
	 */
	@SuppressWarnings("unused")
	private Object getMyService() {
		return (Object) ServiceManager.INSTANCE.locateService("self");
	}

	private static Context getNamingContext(){
		
		if (context != null) return context;
		
		synchronized (ProcessOperatorImpl.class) {
			
			if (context == null) {
				try {
					context = new InitialContext();
				} catch (NamingException e) {
					e.printStackTrace();
				}
			}
		}
		
		return context;
	}
	
	private static DataSource getDataSource(){
		if (dataSource != null) return dataSource;
		
		synchronized (ProcessOperatorImpl.class) {
			try {
				System.out.println("Create DataSource Connection");
				dataSource = (DataSource)getNamingContext().lookup("java:comp/env/" + JDBC_JNDI_REF_NAME);  
			} catch(Exception error) {
				error.printStackTrace();
			}
		}
		        
        return dataSource;
	}
	
	/**
	 * Method generated to support implementation of operation "initProcess" defined for WSDL port type 
	 * named "ProcessOperator".
	 * 
	 * Please refer to the WSDL Definition for more information 
	 * on the type of input, output and fault(s).
	 */
	public String initProcess(String txGroup, String inputDataName) {
		ProcessTemplateData procTemplateData = null;
		try {
			System.out.println("[ProcessOperatorImpl] Running in global transaction -  " + TXUtil.dumpTxId() + " for " + txGroup + ", batch-id " + inputDataName);
			
		} catch (Exception e) {
			throw new ServiceRuntimeException("Failed to get process tempate data!", e);
		} 
		
		Connection conn = null;
		Statement stmt = null;
		
		try {
			
			conn = getDataSource().getConnection();
			stmt = conn.createStatement();
			String dynamicalSQL = null;
			
			//insert a record	
			dynamicalSQL = INSTER_SQL + "12345" + "','" + txGroup +"')" ;
			System.out.println("[ProcessOperatorImpl] Begin to execute sql - " + dynamicalSQL);
			stmt.execute(dynamicalSQL);
			System.out.println("[ProcessOperatorImpl] End to execute sql - " + dynamicalSQL);
			
			dynamicalSQL = DELETE_SQL + "(ID='12345') AND (NAME='" + txGroup +"')";
			System.out.println("[ProcessOperatorImpl] Begin to execute sql - " + dynamicalSQL);
			stmt.execute(dynamicalSQL);
			System.out.println("[ProcessOperatorImpl] End to execute sql - " + dynamicalSQL);
			
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			try {
				if (stmt != null) stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return "sql execution is completed for " + txGroup + ", batch-id " + inputDataName;
	}


}