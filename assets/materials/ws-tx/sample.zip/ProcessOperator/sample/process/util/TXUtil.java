package sample.process.util;

import javax.transaction.SystemException;

public class TXUtil {
	private final static javax.transaction.TransactionManager txMgr = 
		com.ibm.ws.Transaction.TransactionManagerFactory.getTransactionManager();
	
	public static String dumpTxId () {	
		try {
			if (txMgr.getTransaction() != null) {
				return txMgr.getTransaction().toString();
			} 
		} catch (SystemException e) {
			e.printStackTrace();
			return null;
		}
		return null;

	}
}
