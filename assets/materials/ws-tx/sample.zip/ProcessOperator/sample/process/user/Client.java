package sample.process.user;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.UserTransaction;

import com.ibm.jvm.util.ByteArrayOutputStream;
import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.bo.BOXMLSerializer;
import com.ibm.websphere.sca.Service;
import com.ibm.websphere.sca.ServiceManager;
import com.ibm.websphere.sca.scdl.OperationType;
import commonj.sdo.DataObject;
/**
 * 
 * @author lizh@cn.ibm.com
 *
 */
public class Client {
	
	
	
	public static UserTransaction getUserTx () throws NamingException {
		InitialContext ctx = new InitialContext();
        return (UserTransaction) ctx.lookup("java:comp/UserTransaction");
	}
	
	private static interface ActionWithTX {
		String action();
	}
	
	public static BOXMLSerializer boXmlSerializer = (BOXMLSerializer) 
				ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOXMLSerializer");

	private static String doInvokeWithTX(ActionWithTX action) {
		UserTransaction userTx = null;
		try {
			userTx = getUserTx();
			userTx.begin();
			String result = action.action();
			userTx.commit();
			return result;
		} catch (Exception error) {
			error.printStackTrace();
			try {
				userTx.rollback();
			} catch (Exception e) {
				e.printStackTrace();
			} 
		}
		
		 return null;
	}
	
	public static String invokeLooply(final String batchCount, final String txGroupCount) {
		StringBuffer sb = new StringBuffer();
		int txGroups = Integer.parseInt(txGroupCount);
		for (int i = 0; i < txGroups; i++) {
			String result = invoke("TXGroup" + "-" + i, batchCount);
			sb.append(result);
		}
		
		
		return sb.toString();
	}
	
	private static String invoke(final String txGroup, final String batchCount) {
		
		
		return doInvokeWithTX(new ActionWithTX() {
			
			public String action() {
				String refPointToMember0 = "ProcessOperatorPartner0";
				String refPointToMember1 = "ProcessOperatorPartner1";
				
				Service service0 = (Service) ServiceManager.INSTANCE.locateService(refPointToMember0);
				Service service1 = (Service) ServiceManager.INSTANCE.locateService(refPointToMember1);

				BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
				OperationType operType = service0.getReference().getOperationType("initProcess");
				DataObject inputWrapper = null;

				if (operType.isWrapperType(operType.getInputType())) {
					inputWrapper = factory.createByType(operType.getInputType());
					inputWrapper.setString("processTemplateName", txGroup);
					
				} else {
					throw new IllegalArgumentException("This is a doc/lit wrapper style WSDL, We need a wrapper for the input data");
				}

				List<DataObject> results = new ArrayList<DataObject>();
				
				int batch = Integer.parseInt(batchCount);
				StringBuffer sb = new StringBuffer();
				
				for (int i = 0; i < batch; i++) {
					Service service = null;
					
					if (i % 2 == 0) {
						service = service0;
					} else {
						service = service1;
					}
					
					inputWrapper.setString("inputDataName", Integer.toString(i));
					DataObject result = (DataObject) service.invoke(operType.getName(), inputWrapper);
					
					try {
						sb.append(new String(writeBoToByte(result), "UTF-8"));
						sb.append("\n");
					} catch (UnsupportedEncodingException e) {
						
						e.printStackTrace();
					}
				}

				return sb.toString();
				
			}
		});
		
		
	}

	private static byte[] writeBoToByte(DataObject bo) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			boXmlSerializer.writeDataObject(bo, bo.getType().getURI(), bo.getType().getName(), baos);
			baos.flush();

		} catch (IOException e) {
			System.err.println("Failed to serialize BO due to "
					+ e.getMessage());
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			if (baos != null)
				try {
					baos.close();
				} catch (IOException e) {
					System.err.println("Failed to close Output Stream due to "
							+ e.getMessage());
				}
		}
		
		return baos.toByteArray();

	}

}
